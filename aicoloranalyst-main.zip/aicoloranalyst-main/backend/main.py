from fastapi import FastAPI, File, UploadFile, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os
from pathlib import Path

# FastAPI instance
app = FastAPI()

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent
TEMPLATE_DIR = BASE_DIR / "template"
STATIC_DIR = TEMPLATE_DIR / "assets"
UPLOAD_DIR = BASE_DIR / "backend/uploads"

# Static files and templates
app.mount("/assets", StaticFiles(directory=STATIC_DIR), name="assets")
templates = Jinja2Templates(directory=TEMPLATE_DIR)

# Ensure uploads directory exists
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


@app.get("/", response_class=HTMLResponse)
async def upload_form(request: Request):
    """
    Serve the upload form.
    """
    return templates.TemplateResponse("upload.html", {"request": request, "image_url": None})


@app.post("/upload/", response_class=HTMLResponse)
async def handle_upload(request: Request, file: UploadFile = File(...)):
    """
    Handles image uploads, saves them, and returns an updated HTML page.
    """
    # Save the file in the uploads directory
    file_location = UPLOAD_DIR / file.filename
    with open(file_location, "wb") as f:
        f.write(await file.read())

    # Pass the image_url to the template for rendering
    image_url = f"/assets/uploads/{file.filename}"  # Where image will be served from
    return templates.TemplateResponse(
        "upload.html",
        {
            "request": request,
            "image_url": image_url,
        },
    )
